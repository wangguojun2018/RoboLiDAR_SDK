方法一
1、可以通过Cmake-gui 将src的代码生成到Build目录
2、然后在build目录下输入make，即可生成执行文件pcap_parse

方法二
1、可以用clion加载SRC目录，运行生成执行文件

主要代码介绍：
main.cpp中 通过main函数，默认执行网络设备链接（注意执行代码时，要在root权限下才能通过socket使用）
也可以通过宏修改代码，执行本地文件解析




