#include <iostream>
#include <stdio.h>
#include "pcap_manager.h"
using namespace std;

FILE *f_Angle;
FILE *f_Channel;
FILE *f_InIntenCal;

int g_channel_num[16][41];
float g_pitch_angle[16];
float g_inIntenCalDat[1600][16];

bool read_calfile()
{
    /***************Initial for the calibration rom*********************/
    f_Channel = fopen("ChannelNum.csv", "r");
    if(f_Channel == NULL)
    {
        cout << "ChannelNum.csv not found"<<endl;
        return false;
    }
    int loopl = 0;
    int loopm = 0;
    int c[41];
    while (~feof(f_Channel))		//temperature 31 ~ 71
    {
        fscanf(f_Channel, "%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n",
               &c[0], &c[1], &c[2], &c[3], &c[4], &c[5], &c[6], &c[7], &c[8], &c[9], &c[10], &c[11], &c[12], &c[13], &c[14], &c[15],
               &c[16], &c[17], &c[18], &c[19], &c[20], &c[21], &c[22], &c[23], &c[24], &c[25], &c[26], &c[27], &c[28], &c[29], &c[30],
               &c[31], &c[32], &c[33], &c[34], &c[35], &c[36], &c[37], &c[38], &c[39], &c[40]);

        if (c[1] < 100 || c[1]>1000)//TODO:2100 is not the real max value
        {
            for (loopl = 0; loopl < 41; loopl++)
            {
                g_channel_num[loopm][loopl] = c[0];
            }
        }
        else
        {
            for (loopl = 0; loopl < 41; loopl++)
            {
                g_channel_num[loopm][loopl] = c[loopl];
            }
        }
        loopm++;
        if (loopm > 15)
        {
            break;
        }
    }

    f_Angle = fopen("angle.csv", "r");
    if(f_Angle == NULL)
    {
        cout << "angle.csv not found" <<endl;
        return false;
    }
    for (int i = 0; i < 16; i++)
    {
        fscanf(f_Angle, "%f\n", &g_pitch_angle[i]);

    }
    f_InIntenCal = fopen("curves.csv", "r");
    if(f_InIntenCal == NULL)
    {
        cout << "curves.csv not found"<<endl;
        return false;
    }
    int loopi = 0;
    int loopj = 0;
    while (~feof(f_InIntenCal))
    {
        float a[16];
        loopi++;
        if (loopi > 1600)
            break;
        fscanf(f_InIntenCal, "%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f\n", &a[0], &a[1], &a[2], &a[3], &a[4], &a[5], &a[6], &a[7], &a[8], &a[9], &a[10], &a[11], &a[12], &a[13], &a[14], &a[15]);

        for (loopj = 0; loopj < 16; loopj++)
        {
            g_inIntenCalDat[loopi - 1][loopj] = a[loopj];
        }
    }

    fclose(f_Angle);
    fclose(f_InIntenCal);
    fclose(f_Channel);
    return true;
    /**********End of Initial for the Calibration ROM*****************/

}

int main()
{
    char buffer[256];
    getcwd(buffer,256);
    printf( "The   current   directory   is:   %s \n ",  buffer);
    if(read_calfile() == false)
    {
        return -1;
    }

#if 1
    //------------------------------------------在线检测------------------------------------------
    pcap_if_t  *alldevs = nullptr;
    pcap_if_t  *m_dev = nullptr;
    char errbuf[PCAP_ERRBUF_SIZE];
    Pcap_Manager *pcap_manager;
    pcap_manager = new Pcap_Manager();
    int device_num = 1;
    int dev_count = 0;

    //------------------------------------------监听设备网络------------------------------------------

    if (pcap_findalldevs(&alldevs, errbuf) == -1)
    {
        fprintf(stderr, "Error in pcap_findalldevs: %s\n", errbuf);
        return -1;
    }
    for (m_dev = alldevs; m_dev != nullptr; m_dev = m_dev->next) {
        printf("%d. %s\n", dev_count++, m_dev->name);
    }
    //------------------------------------------选择设备网络------------------------------------------

    printf("please input net number\n");
    scanf("%d",&device_num);

    for (m_dev = alldevs, dev_count = 0; dev_count < device_num; m_dev = m_dev->next, dev_count++);
    pcap_manager->alldevs = m_dev;
    printf(" (%s)\n", m_dev->name);

    if (!pcap_manager->Pcap_Connect(m_dev))
    {
        cout <<"Pcap_Connect error";
        return -1;
    }
    //------------------------------------------数据解析------------------------------------------
    pcap_manager->Pcap_Online_Parse();
#else

    //------------------------------------------本地数据解析------------------------------------------
    Pcap_Manager *pcap_manager;
    pcap_manager = new Pcap_Manager();
    pcap_manager->Pcap_File_Parse("LM275.pcap");
    pcap_manager->local_flag = true;
#endif
    cout<<"start success"<<endl;
	return 0;
}
