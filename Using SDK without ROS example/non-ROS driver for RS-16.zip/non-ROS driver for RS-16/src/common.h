#ifndef COMMON_H
#define COMMON_H
#include <pcl/io/io.h>
#include <pcl/console/print.h>
#include <pcl/point_types.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/visualization/cloud_viewer.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/extract_clusters.h>
#include <pcl/console/time.h>
#include <pcl/registration/transforms.h>
#include <pcl/features/normal_3d.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/segmentation/region_growing.h>
#include <pcl/visualization/cloud_viewer.h>
#include <pcl/common/geometry.h>
#include <pcl/point_representation.h>
#include <boost/make_shared.hpp>
#include <pcl/point_representation.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/filters/filter.h>
#include <pcl/features/normal_3d.h>
#include <pcl/registration/icp.h>
#include <pcl/registration/icp_nl.h>
#include <pcl/registration/transforms.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/common/copy_point.h>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/registration/icp.h>
#include <pcl/registration/transforms.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/visualization/pcl_visualizer.h>
#include<iostream>
typedef pcl::PointCloud<pcl::PointXYZRGB>::Ptr PCloudXYZRGBPtr;
typedef pcl::PointCloud<pcl::PointXYZRGB>  PointCloudXYZRGB;
typedef pcl::PointCloud<pcl::PointXYZI>::Ptr PCloudXYZIPtr;
typedef pcl::PointCloud<pcl::PointXYZI>  PointCloudXYZI;

#endif // COMMON_H
