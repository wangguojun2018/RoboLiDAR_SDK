#include <netinet/in.h>
#include "pcap_manager.h"

extern int g_channel_num[16][41];
extern float g_pitch_angle[16];
extern float g_inIntenCalDat[1600][16];

bool Pcap_Manager::Pcap_Connect(pcap_if_t  *m_select_device)
{
    char packet_filter[] = "udp";
    u_int netmask;
    cout << "Open the adapter" << endl;
    /* Open the adapter */
    if ((adhandle = pcap_open_live(m_select_device->name,
                                   65536,
                                   1,
                                   1000,
                                   errbuf
    )) == NULL)
    {
        fprintf(stderr, "\nUnable to open the adapter. %s is not supported by WinPcap\n", m_select_device->name);
        fprintf(stderr, "\nerrbuf : %s \n", errbuf);

        pcap_freealldevs(alldevs);
        return false;
    }

    if (pcap_datalink(adhandle) != DLT_EN10MB)
    {
        fprintf(stderr, "\nThis program works only on Ethernet networks.\n");
        pcap_freealldevs(alldevs);
        return false;
    }

    /*
    if (m_select_device->addresses != NULL)
        netmask = ((struct sockaddr_in *)(m_select_device->addresses->netmask))->sin_addr.s_addr;
    else
        netmask = 0xffffff;
*/
    netmask = 0xffffff;
    //compile the filter
    if (pcap_compile(adhandle, &pcap_packet_filter_, packet_filter, 1, netmask) < 0)
    {
        fprintf(stderr, "\nUnable to compile the packet filter. Check the syntax.\n");
        pcap_freealldevs(alldevs);
        return false;
    }

    //set the filter
    if (pcap_setfilter(adhandle, &pcap_packet_filter_) < 0)
    {
        fprintf(stderr, "\nError setting the filter.\n");
        pcap_freealldevs(alldevs);
        return false;
    }

    printf("\nlistening on %s...\n", m_select_device->name);
    return true;
}

void Pcap_Manager::Pcap_DisConnectNet()
{
    if (alldevs != NULL)
    {
        cout << "free all dev" << endl;
        pcap_freealldevs(alldevs);
        alldevs = NULL;
    }
}

void Pcap_Manager::Pcap_Online_Parse()
{
    while (!complite_flag)
    {
        if (pcap_next_ex(adhandle, &header, &pkt_data) > 0)
        {
            if (header->len != Package_Properties)
            {
                continue;
            }
            Pcap_Data_Parse(pkt_data + Head_OFFSET);
        }
        else
        {
            cout << "pcap packet lose" << endl;
        }
    }
    Pcap_DisConnectNet();
}

void  Pcap_Manager::Pcap_File_Parse(char* Filename)
{
    Local_adhandle = pcap_open_offline(Filename, errbuf);
    if (Local_adhandle == NULL)
    {
        cout << errbuf << endl;
        return;
    }
    while (pcap_next_ex(Local_adhandle, &header, &pkt_data) > 0)
    {
        if (header->len != Package_Properties)
        {
            continue;
        }
       // mutex.lock();
        Pcap_Data_Parse(pkt_data + Head_OFFSET);
        /*
        if (Pause_State)
        {
            cond.wait(&mutex);
        }
        mutex.unlock();
        */
    }
}

bool Pcap_Manager::Pcap_Data_Parse(const u_char * DataBuf)
{
    memset(&msop_packet, 0, sizeof(Msop_Packet_Content));
    memset(&msop_data, 0, sizeof(Msop_Data));
    msop_packet.Head1 = *(DataBuf);
    msop_packet.Head2 = *(DataBuf + 1);
    msop_packet.Head3 = *(DataBuf + 2);
    msop_packet.Head4 = *(DataBuf + 3);
    msop_packet.Head5 = *(DataBuf + 4);
    msop_packet.Head6 = *(DataBuf + 5);
    msop_packet.Head7 = *(DataBuf + 6);
    msop_packet.Head8 = *(DataBuf + 7);
    msop_packet.Head39 = *(DataBuf + 38);
    msop_packet.Head40 = *(DataBuf + 39);
    msop_packet.Head41 = *(DataBuf + 40);
    msop_packet.Head42 = *(DataBuf + 41);
    msop_packet.Factory[0] = *(DataBuf + 1246);
    msop_packet.Factory[1] = *(DataBuf + 1247);

    float bitneg1 = msop_packet.Head40 & 128;
    float highbit1 = msop_packet.Head40 & 127;
    float lowbit1 = msop_packet.Head39 >> 3;
    if (bitneg1 == 128)
    {
        msop_data.temper1 = -1 * (highbit1 * 32 + lowbit1)*0.0625;
    }
    else
    {
        msop_data.temper1 = (highbit1 * 32 + lowbit1)*0.0625;
    }
    float bitneg2 = msop_packet.Head42 & 128;
    float highbit2 = msop_packet.Head42 & 127;
    float lowbit2 = msop_packet.Head41 >> 3;
    if (bitneg2 == 128)
    {
        msop_data.temper2 = -1 * (highbit2 * 32 + lowbit2)*0.0625;
    }
    else
    {
        msop_data.temper2  = (highbit2 * 32 + lowbit2)*0.0625;
    }
    if (
            !(msop_packet.Head3 == 5 &&
                    msop_packet.Head4 == 10 &&
                    msop_packet.Head5 == 90 &&
                    msop_packet.Head6 == 165 &&
                    msop_packet.Head7 == 80 &&
                    msop_packet.Factory[0] == 0 &&
                    msop_packet.Factory[1] == 255
            ))
    {
        return false;
    }
    float distance = 0, inten = 0;
    const u_char* ptr = nullptr;
    int		calIdx = 0;
    int     sDist = 0;
    int     algDist = 0;
    float   realPwr = 0;
    float 	refPwr = 0;
    float   tempInten = 0;
    u_char  iInten = 0;
    int     showPwrs = 0;
    int     showInten = 0;
    for (int i = 0; i < 12; i++)
    {
        ptr = (DataBuf + 42 + 2 + MSOP_BLOCK_LENGTH * i);       //跳过FFEE的检验头
        msop_data.azimuth[i] = (*ptr) * 2.56 + (*(ptr + 1))*0.01;
        for (int j = 0; j < 32; j++)
        {
            calIdx = j % 16;
            ptr = (DataBuf + 42 + 4 + 3 * j + MSOP_BLOCK_LENGTH * i);
            distance = (*ptr) * 256 + (*(ptr + 1));
            inten = (*(ptr + 2));
            if (j > 15)
            {
                msop_data.distance[i][j] = PixelToDistance(distance, j - 16, msop_data.temper1) ;
            }
            else
            {
                msop_data.distance[i][j] = PixelToDistance(distance, j, msop_data.temper1) ;
            }
            msop_data.intensity[i][j] = calibrateIntensity(inten, calIdx, distance,msop_data.temper1);
            msop_data.channel[i][j] = g_pitch_angle[j % 16];
        }
    }

    for (int i = 0; i < 12; i++)
    {
        if (temp_Amuth - msop_data.azimuth[i]>300)
        {
            speed_value[i]= (360 + msop_data.azimuth[i] - temp_Amuth) / 100.0f;
        }
        else
        {
            speed_value[i] = (msop_data.azimuth[i] - temp_Amuth) / 100.0f;
        }
        if (speed_value[i] <= 0)
        {
           	cout << "speed_value = " << speed_value[i] << endl; //码盘翻转
        }
        temp_Amuth = msop_data.azimuth[i];
    }
    for (int i = 0; i < 12; i++)
    {
        for (int j = 0; j < 32; j++)
        {
            if (j<16)
            {
                real_azimuth[i][j] = msop_data.azimuth[i] + speed_value[i] * 3 * j;
            }
            else
            {
                real_azimuth[i][j] = (msop_data.azimuth[i] + speed_value[i] * 2) + speed_value[i] * 3 * j;
            }

        }
    }
    for (int i = 0; i < 12; i++)
    {
        for (int j = 0; j < 32; j++)
        {
            cloud_point.x = msop_data.distance[i][j] * cos(DEG2RAD(real_azimuth[i][j]))*cos(DEG2RAD(msop_data.channel[i][j]));
            cloud_point.y = msop_data.distance[i][j] * sin(DEG2RAD(real_azimuth[i][j]))*cos(DEG2RAD(msop_data.channel[i][j]));
            cloud_point.z = msop_data.distance[i][j] * sin(DEG2RAD(msop_data.channel[i][j]));
            cloud_point.intensity = msop_data.intensity[i][j];
            cloud_vector.push_back(cloud_point);
            if (cloud_vector.size() == Cloud_Number * Frame_Number)
            {
                cloud_ptr->clear();
                cloud_ptr->width = cloud_vector.size();
                cloud_ptr->height = 1;
                cloud_ptr->is_dense = false;
                cloud_ptr->points.resize(cloud_ptr->width * cloud_ptr->height);
                for (int k = 0; k < cloud_vector.size(); k++)
                {
                    cloud_ptr->points[k] = cloud_vector[k];
                }
               transCloudSort(cloud_ptr,cloud_ptr_output);
                cloud_vector.clear();
                if (local_flag)
                {
                    usleep(10000);
                }
            }

        }
    }
    return true;
}
float Pcap_Manager::PixelToDistance(int pixelValue, int channel, double temperature)
{
    float DistanceValue = 0;
    if (pixelValue < 20 || pixelValue > 16000)                //reference signal:20170410change
    {
        DistanceValue = 0;
    }
    else
    {
        int indexTemper = estimateTemperature(temperature) - 30;
		if (pixelValue <= g_channel_num[channel][indexTemper])
		{
			DistanceValue = 0.0;
		}
		else
		{
			DistanceValue = (float)(pixelValue - g_channel_num[channel][indexTemper]);
		}
    }
    return DistanceValue;
}

float Pcap_Manager::calibrateIntensity(float intensity, int calIdx, int distance, double temper)
{
    int algDist;
    int sDist;
    int uplimitDist;
    float realPwr;
    float refPwr;
    float tempInten;
    int indexTemper = estimateTemperature(temper) - 30;
	uplimitDist = g_channel_num[calIdx][indexTemper] + 1400;
    realPwr = intensity;

    if ((int)realPwr < 126)
        realPwr = realPwr * 4.0;
    else if ((int)realPwr >= 126 && (int)realPwr < 226)
        realPwr = (realPwr - 125.0) * 16.0 + 500.0;
    else
        realPwr = (realPwr - 225.0) * 256.0 + 2100.0;

    sDist = (distance > g_channel_num[calIdx][indexTemper]) ? distance : g_channel_num[calIdx][indexTemper];
	sDist = (sDist < uplimitDist) ? sDist : uplimitDist;
	algDist = sDist - g_channel_num[calIdx][indexTemper];
    refPwr = g_inIntenCalDat[algDist][calIdx];
    tempInten = (200 * refPwr) / realPwr;
    tempInten = (int)tempInten > 255 ? 255.0 : tempInten;
    return tempInten;
}

int Pcap_Manager::estimateTemperature(float temper)
{

    int temp = floor(temper + 0.5);
    if (temp < 30)
    {
        temp = 30;
    }
    else if (temp>70)
    {
        temp = 70;
    }

    return temp;
}

void Pcap_Manager::transCloudSort( PCloudXYZIPtr in_cloud_ptr,PCloudXYZIPtr out_cloud_ptr)
{
    int height = 16;
    int width = in_cloud_ptr->size() / height;
    out_cloud_ptr->height = height;
    out_cloud_ptr->width = width;
    out_cloud_ptr->resize(height * width);
    int index = 0;
    for(int i=0;i<width;++i)
    {
        for(int j=0;j<height;++j)
        {
            out_cloud_ptr->points[j*width + i] = in_cloud_ptr->points[index];
            index++;
        }
    }
}

Pcap_Manager::Pcap_Manager()
{
    cloud_ptr = pcl::PointCloud<pcl::PointXYZI>::Ptr(new pcl::PointCloud<pcl::PointXYZI>);
    cloud_ptr_output = pcl::PointCloud<pcl::PointXYZI>::Ptr(new pcl::PointCloud<pcl::PointXYZI>);
    cloud_rgb_ptr= pcl::PointCloud<pcl::PointXYZRGB>::Ptr(new pcl::PointCloud<pcl::PointXYZRGB>);
}
Pcap_Manager::~Pcap_Manager()
{

}