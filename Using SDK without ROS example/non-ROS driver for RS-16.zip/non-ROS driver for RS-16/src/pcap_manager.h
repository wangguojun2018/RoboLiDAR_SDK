#ifndef PCAP_PARSE_PCAP_MANAGER_H
#define PCAP_PARSE_PCAP_MANAGER_H

#include "pcap.h"
#include "common.h"
#include <math.h>
#include <iostream>
#include <vector>
#include <stdio.h>
#define Head_OFFSET 42
#define Package_Properties 1290
#define Max_Distance 20000
#define Cloud_Number 12 * 32
#define Frame_Number 84
static const int MSOP_BLOCK_LENGTH = 100;

struct Msop_Packet_Content
{
    unsigned char Head1;
    unsigned char Head2;
    unsigned char Head3;
    unsigned char Head4;
    unsigned char Head5;
    unsigned char Head6;
    unsigned char Head7;
    unsigned char Head8;
    unsigned char UnUse[30];
    unsigned char Head39;
    unsigned char Head40;
    unsigned char Head41;
    unsigned char Head42;

    unsigned char FLAG[12][2];  //0xffee
    unsigned char Azimuth[12][2];
    unsigned char Distance[12][32][2];
    unsigned char Intensity[12][32];
    unsigned char TimeStamp[4];
    unsigned char Factory[2];
};

struct Msop_Data
{
    float azimuth[12];
    double temper1;
    double temper2;
    float distance[12][32];
    float intensity[12][32];
    float channel[12][32];
    long PointPos[12][32];
};

class Pcap_Manager
{
public:

    Pcap_Manager();
    ~Pcap_Manager();

    bool local_flag = false;
    bool complite_flag = false;
    pcap_if_t  *alldevs = NULL;
    pcap_t *adhandle = NULL;
    pcap_t *Local_adhandle = NULL;
    char errbuf[PCAP_ERRBUF_SIZE];
    const u_char *pkt_data = NULL;
    pcap_pkthdr * header = NULL;
    bpf_program pcap_packet_filter_;

    bool Pcap_Connect(pcap_if_t  *m_select_device);
    void Pcap_DisConnectNet();
    void Pcap_File_Parse(char* filename);//本地数据解析
    void Pcap_Online_Parse();//在线数据解析
    bool Pcap_Data_Parse(const u_char * DataBuf);

    Msop_Packet_Content msop_packet;
    Msop_Data msop_data;

    int estimateTemperature(float temper);
    float calibrateIntensity(float intensity, int calIdx, int distance,double temper);
    float PixelToDistance(int pixelValue, int channel, double temperature);

    std::vector<pcl::PointXYZI> cloud_vector;
    pcl::PointXYZI cloud_point;
    PCloudXYZRGBPtr cloud_rgb_ptr;
    PCloudXYZIPtr cloud_ptr;
    PCloudXYZIPtr cloud_ptr_output; //驱动解析后的点云输出

    float temp_Amuth = 0;
    float speed_value[12];
    float real_azimuth[12][32];
    void transCloudSort( PCloudXYZIPtr in_cloud_ptr,PCloudXYZIPtr out_cloud_ptr);    //将点云转换成16线对齐形式


};

#endif //PCAP_PARSE_PCAP_MANAGER_H
