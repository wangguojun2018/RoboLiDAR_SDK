//
// Created by mjj on 17-11-13.
//

#ifndef ROBOSENSE_FREE_SPACE_TOOL_H
#define ROBOSENSE_FREE_SPACE_TOOL_H

#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <opencv2/opencv.hpp>
#include "dependence/cart_grid.h"

namespace Robosense
{
    class MapFreeSpaceLabelTool
    {
    public:
        MapFreeSpaceLabelTool();
        ~MapFreeSpaceLabelTool(){}

        void genFeatureMap(const std::string& single_frame_global_path,const std::string& single_frame_pose_txt_path,
                           const std::string& save_map_feature_path);

        bool setSingleImgSize(const float& size = 500.);
        bool setGridSize(const float& size = 0.1);
        bool setDensityMaxSize(const int& size = 100);
    protected:
        pcl::PointCloud<pcl::PointXYZI>::Ptr input_cloud_ptr_;
        float img_size_,grid_size_,valid_range_;
        int max_density_size_;
        CartGrid cart_;
    private:
    };
}


#endif //ROBOSENSE_FREE_SPACE_TOOL_H
