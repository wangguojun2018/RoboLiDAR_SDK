//
// Created by mjj on 17-11-13.
//

#ifndef ROBOSENSE_MAP_FREE_SPACE_H
#define ROBOSENSE_MAP_FREE_SPACE_H

#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <opencv2/opencv.hpp>
#include "free_space_tool/free_space_type.h"

namespace Robosense
{
    class MapFreeSpace
    {
    public:
        MapFreeSpace();
        ~MapFreeSpace(){}

        bool setMapLabel(const std::string& map_label_path);
        bool mapFreeSpace(const pcl::PointCloud<pcl::PointXYZI>::ConstPtr in_cloud_ptr,
                          const Eigen::Matrix4f& global_trans_mat,pcl::PointCloud<pcl::PointXYZI>::Ptr roi_cloud_ptr);
    protected:
        std::vector<std::vector<cv::Mat> > map_label_;
        float max_x_,max_y_,min_x_,min_y_;
        float label_img_size_,label_grid_size_;
    private:
    };
}

#endif //ROBOSENSE_MAP_FREE_SPACE_H
