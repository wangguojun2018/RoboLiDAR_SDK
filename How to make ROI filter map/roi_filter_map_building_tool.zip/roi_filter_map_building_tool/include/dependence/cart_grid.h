//
// Created by mjj on 17-11-13.
//

#ifndef ROBOSENSE_CART_GRID_H
#define ROBOSENSE_CART_GRID_H

#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <opencv2/opencv.hpp>
#include "common.h"

namespace Robosense
{
    class CartGrid
    {
    public:
        CartGrid();
        ~CartGrid(){}

        bool cartGrid(const pcl::PointCloud<pcl::PointXYZI>::ConstPtr in_cloud_ptr,
                      std::vector<std::vector<std::vector<pcl::PointXYZI> > >& grids);

        bool getIndex(const pcl::PointXYZI& in_pt,cv::Point2i& out_index);
        void getLeavePts(pcl::PointCloud<pcl::PointXYZI>::Ptr leave_cloud_ptr);
        void getGridPtsSize(cv::Point2i& size);

        bool setGrid(const Range3D& range = Range3D(-50.,50.,-50.,50.,-3.,0.),const float& size = 0.5);
        void setUserDefineCartHT(float (*pf)(const pcl::PointXYZI& ) = NULL);
    protected:
        void setConditionMat();

        float (*computeCartHeightThre_)(const pcl::PointXYZI& point_pt) = NULL;
        float computeCartHeightThre(const pcl::PointXYZI& in_pt);
        cv::Mat height_thre_mat_;

        int grid_length_,grid_width_;
        pcl::PointCloud<pcl::PointXYZI>::Ptr leave_cloud_ptr_;
        Range3D range_;
        float grid_size_;
    private:
    };
}

#endif //ROBOSENSE_CART_GRID_H
