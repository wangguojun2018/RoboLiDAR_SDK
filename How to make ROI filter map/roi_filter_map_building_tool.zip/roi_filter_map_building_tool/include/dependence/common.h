//
// Created by mjj on 17-11-13.
//

#ifndef ROBOSENSE_COMMON_H
#define ROBOSENSE_COMMON_H

#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <opencv2/opencv.hpp>

namespace Robosense
{
    void getOccupyMat(const std::vector<std::vector<std::vector<pcl::PointXYZI> > >& grids,cv::Mat& occupy_mat);
    float computeXYDis(const pcl::PointXYZI& pt);
    void getTransformMat(const std::vector<float>& in_vec,Eigen::Matrix4f& out_tranform_mat);
    bool computeZ(const pcl::PointXYZI& pt1,const pcl::PointXYZI& pt2);
    bool isNanPoint(const pcl::PointXYZI& pt);
    bool isInvalidPoint(const pcl::PointXYZI& pt);
    void readPose(std::string str_path,std::vector<std::vector<float> >&pose);

    struct Range3D
    {
        Range3D();
        Range3D(float x_min, float x_max, float y_min, float y_max, float z_min, float z_max);
        Range3D(const Range3D &r);
        Range3D &operator=(const Range3D &r);
        float xmin, xmax, ymin, ymax, zmin, zmax;
    };

    template<typename T>
    std::string num2str(T num)
    {
        std::stringstream ss;
        std::string st;
        ss << num;
        ss >> st;
        return st;
    }
}

#endif //ROBOSENSE_COMMON_H
