#include <ros/ros.h>
#include <ros/package.h>
#include "free_space_tool/free_space_tool.h"

int main(int argc, char** argv)
{
    ros::init(argc,argv,"generate_feature_map");
    ros::NodeHandle node;
    ros::NodeHandle private_nh("~"); //parameter node

    std::string pcd_path,pose_txt_path,feature_map_path;
    float img_range,grid_range, valid_range;
    int max_density_size;

    private_nh.param("pcd_path",pcd_path,std::string(""));
    private_nh.param("pose_txt_path",pose_txt_path,std::string(""));
    private_nh.param("feature_map_path",feature_map_path,std::string(""));
    private_nh.param("img_range",img_range,float(500.));
    private_nh.param("grid_range",grid_range,float(0.1));
    private_nh.param("max_density_size",max_density_size,int(100));

    Robosense::MapFreeSpaceLabelTool free_tool;
    free_tool.setSingleImgSize(img_range);
    free_tool.setGridSize(grid_range);
    free_tool.setDensityMaxSize(max_density_size);
    free_tool.genFeatureMap(pcd_path,pose_txt_path,feature_map_path);

    return 0;
}
