#include <ros/ros.h>
#include <pcl_ros/point_cloud.h>
#include <pcl/io/pcd_io.h>
#include <pcl/common/transforms.h>
#include <nav_msgs/Odometry.h>
#include <tf/tf.h>
#include <opencv2/opencv.hpp>
#include "dependence/common.h"
#include "std_msgs/String.h"

static ros::Publisher pub_rslidar;
static ros::Publisher pub_odometry;
static std::vector<std::vector<float> > pose;

void poll(const int& k);

static std::string pcd_path;

int main(int argc, char** argv)
{
    ros::init(argc, argv, "map_free_space_virtual_node");
    ros::NodeHandle node;
    ros::NodeHandle private_nh("~");

    pub_rslidar = node.advertise<pcl::PointCloud<pcl::PointXYZI> >("map_free_space_points",10);
    pub_odometry = node.advertise<nav_msgs::Odometry>("odometry",10);


    std::string pose_txt_path;
    private_nh.param("pcd_path",pcd_path,std::string(""));
    private_nh.param("pose_txt_path",pose_txt_path,std::string(""));

    Robosense::readPose(pose_txt_path,pose);

    int k = 0;
    while(ros::ok())
    {
        poll(k);
        k+=1;
        ros::spinOnce();
        if (k >= pose.size())
        {
            k = 0;
        }
    }

    return 0;
}

void poll(const int& k)
{
    std::string single_pcd_path = pcd_path + "/" + Robosense::num2str(pose[k][0]) + "global.pcd";
    pcl::PointCloud<pcl::PointXYZI>::Ptr in_cloud_ptr(new pcl::PointCloud<pcl::PointXYZI>);
    if (pcl::io::loadPCDFile<pcl::PointXYZI> (single_pcd_path, *in_cloud_ptr) == -1)
    {
        std::cout<<"can not read the global"<<Robosense::num2str(pose[k][0])<<"global.pcd"<<std::endl;
        return;
    }

    Eigen::Matrix4f trans_mat;
    Robosense::getTransformMat(pose[k],trans_mat);
    Eigen::Matrix4f inverse_mat = trans_mat.inverse();
    pcl::transformPointCloud(*in_cloud_ptr,*in_cloud_ptr,inverse_mat);

    in_cloud_ptr->header.frame_id = "rslidar";
    nav_msgs::Odometry tmp_odometry;
    tmp_odometry.pose.pose.position.x = pose[k][1];
    tmp_odometry.pose.pose.position.y = pose[k][2];
    tmp_odometry.pose.pose.position.z = pose[k][3];
    tf::Quaternion q = tf::createQuaternionFromRPY(pose[k][4],pose[k][5],pose[k][6]);
    tmp_odometry.pose.pose.orientation.x = q.x();
    tmp_odometry.pose.pose.orientation.y = q.y();
    tmp_odometry.pose.pose.orientation.z = q.z();
    tmp_odometry.pose.pose.orientation.w = q.w();
    tmp_odometry.header.frame_id = "rslidar";
    pub_rslidar.publish(in_cloud_ptr);
    pub_odometry.publish(tmp_odometry);
    usleep(100000);
    std::cout<<"publish "<<Robosense::num2str(k)<<std::endl;
}