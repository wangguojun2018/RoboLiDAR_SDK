//
// Created by mjj on 17-9-1.
//

#include <fstream>
#include <pcl/io/pcd_io.h>
#include <pcl/common/transforms.h>
#include <ros/ros.h>
#include <pcl_ros/point_cloud.h>

#include <nav_msgs/Odometry.h>
#include <nav_msgs/Path.h>
#include <tf/tf.h>

#include "free_space_tool/map_free_space.h"
#include "dependence/common.h"

static ros::Publisher pub_free_space;
static ros::Publisher pub_full_cloud;
static Robosense::MapFreeSpace map_free_space;

static pcl::PointCloud<pcl::PointXYZI>::Ptr pcd_cloud_ptr(new pcl::PointCloud<pcl::PointXYZI>);

void pcd_callback(const pcl::PointCloud<pcl::PointXYZI>::ConstPtr& input)
{
    *pcd_cloud_ptr = *input;
}

void pose_callback(const nav_msgs::OdometryConstPtr &odmetry_msg)
{
    geometry_msgs::Quaternion q = odmetry_msg->pose.pose.orientation;
    float cur_yaw = tf::getYaw(q);
    std::vector<float> tranform_vec(7,0.);
    tranform_vec[1] = odmetry_msg->pose.pose.position.x;
    tranform_vec[2] = odmetry_msg->pose.pose.position.y;
    tranform_vec[3] = odmetry_msg->pose.pose.position.z;
    tranform_vec[6] = cur_yaw;

    Eigen::Matrix4f tranform_matrix;
    Robosense::getTransformMat(tranform_vec,tranform_matrix);


    pcl::PointCloud<pcl::PointXYZI>::Ptr roi_cloud_ptr(new pcl::PointCloud<pcl::PointXYZI>);
    map_free_space.mapFreeSpace(pcd_cloud_ptr,tranform_matrix,roi_cloud_ptr);
    pcl::PointCloud<pcl::PointXYZRGB>::Ptr free_space_ptr(new pcl::PointCloud<pcl::PointXYZRGB>);
    for (int k = 0; k < roi_cloud_ptr->size(); ++k)
    {
        pcl::PointXYZI tmp_pt = roi_cloud_ptr->points[k];
        pcl::PointXYZRGB tmp_rgb;
        tmp_rgb.x = tmp_pt.x;
        tmp_rgb.y = tmp_pt.y;
        tmp_rgb.z = tmp_pt.z;
        tmp_rgb.g = 255;
        free_space_ptr->push_back(tmp_rgb);
    }

    free_space_ptr->header.frame_id = "rslidar";
    pcd_cloud_ptr->header.frame_id = "rslidar";
    pub_free_space.publish(free_space_ptr);
    pub_full_cloud.publish(pcd_cloud_ptr);
}

int main(int argc, char** argv)
{
    ros::init(argc, argv, "map_free_space_online_demo");
    ros::NodeHandle node;
    ros::NodeHandle private_nh("~");

    ros::Subscriber sub_pcd = node.subscribe("map_free_space_points",10,pcd_callback);
    ros::Subscriber sub_pose = node.subscribe("odometry",10,pose_callback);
    pub_free_space = node.advertise<pcl::PointCloud<pcl::PointXYZRGB> >("map_free_space",10);
    pub_full_cloud = node.advertise<pcl::PointCloud<pcl::PointXYZI> >("rs_points",10);

    std::string feature_map_path;
    private_nh.param("feature_map_path",feature_map_path, std::string(""));
    map_free_space.setMapLabel(feature_map_path);

    ros::spin();
    return 0;
}