//
// Created by mjj on 17-11-13.
//

#include "free_space_tool/map_free_space.h"
#include "dependence/common.h"
#include "free_space_tool/free_space_type.h"
#include <pcl/io/pcd_io.h>
#include <pcl/common/transforms.h>

namespace Robosense
{
    MapFreeSpace::MapFreeSpace()
    {
    }

    bool MapFreeSpace::setMapLabel(const std::string& map_label_path)
    {

        std::string map_info_path = map_label_path + "/info.txt";
        std::ifstream ifile;  //需要包含头文件<fstream>
        ifile.open(map_info_path.c_str());
        assert(ifile.is_open());

        map_label_.clear();
        std::string line;
        while (getline(ifile,line))
        {
            std::istringstream infile(line);
            std::string tmp_str;
            infile >> tmp_str;
            if (tmp_str == "img_size:")
            {
                infile >> tmp_str;
                label_img_size_ = atof(tmp_str.c_str());
            }
            if (tmp_str == "grid_size:")
            {
                infile >> tmp_str;
                label_grid_size_ = atof(tmp_str.c_str());
            }
            if (tmp_str == "vec_length:")
            {
                infile >> tmp_str;
                map_label_.resize(atoi(tmp_str.c_str()));
            }
            if (tmp_str == "vec_width:")
            {
                infile >> tmp_str;
                int width = atoi(tmp_str.c_str());
                for (int j = 0; j < map_label_.size(); ++j)
                {
                    map_label_[j].resize(width);
                }
            }
            if (tmp_str == "max_size(max_x,min_x,max_y,min_y):")
            {
                infile >> tmp_str;
                max_x_ = atof(tmp_str.c_str());
                infile >> tmp_str;
                min_x_ = atof(tmp_str.c_str());
                infile >> tmp_str;
                max_y_ = atof(tmp_str.c_str());
                infile >> tmp_str;
                min_y_ = atof(tmp_str.c_str());
            }
        }

        for (int j = 0; j < map_label_.size(); ++j)
        {
            for (int i = 0; i < map_label_[j].size(); ++i)
            {
                std::string tmp_label_path = map_label_path + "/" + num2str(j) + "_" + num2str(i) + "_label.png";
                map_label_[j][i] = cv::imread(tmp_label_path);
            }
        }

        return true;
    }

    bool MapFreeSpace::mapFreeSpace(const pcl::PointCloud<pcl::PointXYZI>::ConstPtr in_cloud_ptr,
                                    const Eigen::Matrix4f& global_trans_mat,pcl::PointCloud<pcl::PointXYZI>::Ptr roi_cloud_ptr)
    {
        if (map_label_.empty())
        {
            std::cerr<<"has not set label data yet!"<<std::endl;
            return false;
        }
        if (in_cloud_ptr->empty())
        {
            std::cerr<<"the input cloud for map free space is empty!!"<<std::endl;
            return false;
        }
        pcl::PointCloud<pcl::PointXYZI>::Ptr transform_cloud_ptr(new pcl::PointCloud<pcl::PointXYZI>);
        pcl::transformPointCloud(*in_cloud_ptr,*transform_cloud_ptr,global_trans_mat);
        roi_cloud_ptr->clear();
        for (int i = 0; i < transform_cloud_ptr->size(); ++i)
        {
            pcl::PointXYZI tmp_pt = transform_cloud_ptr->points[i];
            if (isNanPoint(tmp_pt))continue;
            if (tmp_pt.x < min_x_ || tmp_pt.x > max_x_ || tmp_pt.y < min_y_ || tmp_pt.y > max_y_)continue;
            int index_x = (tmp_pt.x - min_x_) / label_img_size_;
            int index_y = (tmp_pt.y - min_y_) / label_img_size_;
            int index_xx = (tmp_pt.x - min_x_ - index_x * label_img_size_) / label_grid_size_;
            int index_yy = (tmp_pt.y - min_y_ - index_y * label_img_size_) / label_grid_size_;
            if ((int)map_label_[index_y][index_x].at<cv::Vec3b>(index_yy,index_xx)[0] >= (ROBOSENSE_MAP_FREE_SPACE / 2))
            {
                roi_cloud_ptr->push_back(in_cloud_ptr->points[i]);
            }
        }
        return true;
    }
}