//
// Created by mjj on 17-11-13.
//
#include "free_space_tool/free_space_tool.h"
#include <pcl/io/pcd_io.h>
#include <pcl/common/transforms.h>
#include "dependence/common.h"
#include "free_space_tool/free_space_type.h"
#include <pcl/visualization/cloud_viewer.h>

namespace Robosense
{
    bool computeX(std::vector<float> pose1,std::vector<float>pose2)
    {
        return pose1[1] < pose2[1];
    }
    bool computeY(std::vector<float> pose1,std::vector<float>pose2)
    {
        return pose1[2] < pose2[2];
    }

    MapFreeSpaceLabelTool::MapFreeSpaceLabelTool()
    {
        img_size_ = 500.;
        grid_size_ = 0.1;
        valid_range_ = 50.;
        max_density_size_ = 100;
        input_cloud_ptr_.reset(new pcl::PointCloud<pcl::PointXYZI>);
    }

    bool MapFreeSpaceLabelTool::setDensityMaxSize(const int& size)
    {
        if (size < 0)
        {
            std::cerr<<"illeagl density max size for map free space!"<<std::endl;
            return false;
        }
        max_density_size_ = size;
        return true;
    }

    bool MapFreeSpaceLabelTool::setGridSize(const float& size)
    {
        if (size < 0)
        {
            std::cerr<<"illeagl grid size for map free space!"<<std::endl;
            return false;
        }
        grid_size_ = size;
        return true;
    }

    bool MapFreeSpaceLabelTool::setSingleImgSize(const float& size)
    {
        if (size < 0)
        {
            std::cerr<<"illeagl single img size for map free space!"<<std::endl;
            return false;
        }
        img_size_ = size;
        return true;
    }

    void MapFreeSpaceLabelTool::genFeatureMap(const std::string& single_frame_global_path,
                                              const std::string& single_frame_pose_txt_path, const std::string& save_map_feature_path)
    {
        std::vector<std::vector<float> > pose;
        readPose(single_frame_pose_txt_path,pose);

        float min_x,max_x,min_y,max_y;

        std::vector<std::vector<float> >tmp_pose = pose;
        std::sort(tmp_pose.begin(),tmp_pose.end(),computeX);
        min_x = tmp_pose[0][1] - valid_range_;
        max_x = tmp_pose[tmp_pose.size() - 1][1] + valid_range_;
        std::sort(tmp_pose.begin(),tmp_pose.end(),computeY);
        min_y = tmp_pose[0][2] - valid_range_;
        max_y = tmp_pose[tmp_pose.size() - 1][2] + valid_range_;

        int length = (max_y - min_y) / img_size_ + 1;
        int width = (max_x - min_x) / img_size_ + 1;
        int mat_length = img_size_ / grid_size_ + 1;
        int mat_width = img_size_ / grid_size_ + 1;

        std::vector<std::vector<cv::Mat> > density_mat_vec(length,std::vector<cv::Mat>(width));
        for (int j = 0; j < length; ++j)
        {
            for (int i = 0; i < width; ++i)
            {
                density_mat_vec[j][i] = cv::Mat::zeros(mat_length,mat_width,CV_32S);
            }
        }

        for (int k = 0; k < pose.size(); ++k)
        {
            std::string single_pcd_path = single_frame_global_path + "/" + num2str(pose[k][0]) + "global.pcd";
            pcl::PointCloud<pcl::PointXYZI>::Ptr in_cloud_ptr(new pcl::PointCloud<pcl::PointXYZI>);
            if (pcl::io::loadPCDFile<pcl::PointXYZI> (single_pcd_path, *in_cloud_ptr) == -1)
            {
                std::cout<<"can not read the test"<<num2str(pose[k][0])<<"global.pcd"<<std::endl;
                continue;
            }

            Eigen::Matrix4f transform_mat,inverse_mat;
            getTransformMat(pose[k],transform_mat);
            inverse_mat = transform_mat.inverse();

            pcl::PointCloud<pcl::PointXYZI>::Ptr ori_cloud_ptr(new pcl::PointCloud<pcl::PointXYZI>);
//            *ori_cloud_ptr = *in_cloud_ptr;
            pcl::transformPointCloud(*in_cloud_ptr,*ori_cloud_ptr,inverse_mat);

//            pcl::visualization::CloudViewer viewer("have a look");
//            viewer.showCloud(ori_cloud_ptr);
//            while (!viewer.wasStopped ())
//            {
//
//            }

            pcl::PointCloud<pcl::PointXYZI>::Ptr filter_cloud_ptr(new pcl::PointCloud<pcl::PointXYZI>);

            std::vector<std::vector<std::vector<pcl::PointXYZI> > > grids;
            cart_.cartGrid(ori_cloud_ptr,grids);
            int grid_length = grids.size();
            int grid_width = grids[0].size();

            for (int j = 0; j < grid_length; ++j)
            {
                for (int i = 0; i < grid_width; ++i)
                {
                    if (grids[j][i].empty())continue;
                    float lowest_height = grids[j][i][0].z;
                    for (int kk = 0; kk < grids[j][i].size(); ++kk)
                    {
                        pcl::PointXYZI tmp_pt = grids[j][i][kk];
                        if (isInvalidPoint(tmp_pt))continue;
                        if (tmp_pt.z - lowest_height > 0.2 || tmp_pt.z > 0.)break;
                        filter_cloud_ptr->push_back(tmp_pt);
                    }
                }
            }

            //**处理打标数据
            pcl::PointCloud<pcl::PointXYZI>::Ptr transform_cloud_ptr(new pcl::PointCloud<pcl::PointXYZI>);
            pcl::transformPointCloud(*filter_cloud_ptr,*transform_cloud_ptr,transform_mat);

            for (int kk = 0; kk < transform_cloud_ptr->size(); ++kk)
            {
                pcl::PointXYZI tmp_pt = transform_cloud_ptr->points[kk];
                if (tmp_pt.x <= min_x || tmp_pt.x >= max_x || tmp_pt.y <= min_y || tmp_pt.y >= max_y)continue;
                int index_x = (tmp_pt.x - min_x) / img_size_;
                int index_y = (tmp_pt.y - min_y) / img_size_;
                int index_xx = (tmp_pt.x - min_x - index_x * img_size_) / grid_size_;
                int index_yy = (tmp_pt.y - min_y - index_y * img_size_) / grid_size_;
                int tmp_num = density_mat_vec[index_y][index_x].at<int>(index_yy,index_xx);
                if (tmp_num < max_density_size_)
                {
                    density_mat_vec[index_y][index_x].at<int>(index_yy,index_xx)++;
                }
            }

            std::cout<<num2str(k)<<" processd!"<<std::endl;
        }

        std::string save_info_path = save_map_feature_path + "/info.txt";

        std::ofstream outfile;
        outfile.open(save_info_path.c_str());
        assert(outfile.is_open());
        outfile << "img_size: " <<img_size_<<std::endl;
        outfile << "grid_size: " <<grid_size_<<std::endl;
        outfile << "vec_length: " <<length<<std::endl;
        outfile << "vec_width: " <<width<<std::endl;
        outfile << "max_size(max_x,min_x,max_y,min_y): " <<max_x<<" "<<min_x<<" "<<max_y<<" "<<min_y<<std::endl;
        outfile.close();

        //*****保存打标数据
        for (int j = 0; j < length; ++j)
        {
            for (int i = 0; i < width; ++i)
            {
                cv::Mat tmp_density_mat = density_mat_vec[j][i].clone();
                cv::Mat tt_density;
                tt_density = cv::Mat::zeros(tmp_density_mat.size(),CV_32F);
                tmp_density_mat.convertTo(tt_density,CV_32F);

                cv::normalize(tt_density,tt_density,1.0,0.0,cv::NORM_MINMAX);

                tt_density *= 255.;

                cv::Mat save_density;
                tt_density.convertTo(save_density,CV_8U);
                std::string save_density_path = save_map_feature_path + "/density_" + num2str(j) + "_" + num2str(i) + ".png";
                cv::imwrite(save_density_path,save_density);
            }
        }
        std::cout<<"all done!!"<<std::endl;
    }
}