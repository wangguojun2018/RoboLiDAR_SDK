#include "dependence/common.h"
#include "free_space_tool/free_space_type.h"
#include <fstream>

namespace Robosense
{
    void readPose(std::string str_path,std::vector<std::vector<float> >&pose)
    {
        std::ifstream ifile;  //需要包含头文件<fstream>
        ifile.open(str_path.c_str());     

		if (!ifile.is_open())
		{
			std::cout<<"Please input the pose data."<<std::endl;
			return;
		}			

        std::string line;
        while (getline(ifile,line))
        {
            std::istringstream infile(line);
            std::string tmp_str;
//            infile >> tmp_str;
            std::vector<float> tmp_pose;
            for (int i = 0; i < 7; ++i)
            {
                infile >> tmp_str;
                tmp_pose.push_back(atof(tmp_str.c_str()));
            }
            pose.push_back(tmp_pose);
        }
        ifile.close();
    }

    void getOccupyMat(const std::vector<std::vector<std::vector<pcl::PointXYZI> > >& grids,cv::Mat& occupy_mat)
    {
        int length = grids.size();
        int width = grids[0].size();
        occupy_mat = cv::Mat::zeros(length,width,CV_32S);
        occupy_mat.setTo(ROBOSENSE_NO_OCCUPY);
        for (int j = 0; j < length; ++j)
        {
            for (int i = 0; i < width; ++i)
            {
                if (grids[j][i].empty())continue;
                occupy_mat.at<int>(j,i) = ROBOSENSE_OCCUPY;
            }
        }
    }

    float computeXYDis(const pcl::PointXYZI& pt)
    {
        return sqrtf(pt.x*pt.x + pt.y*pt.y);
    }

    bool isInvalidPoint(const pcl::PointXYZI& pt)
    {
        if (std::isnan(pt.x) || std::isnan(pt.y) || std::isnan(pt.z) ||std::isnan(pt.intensity) ||
            ((fabs(pt.x) < ROBOSENSE_NEAR_ZERO) && (fabs(pt.y) < ROBOSENSE_NEAR_ZERO) && (fabs(pt.z) < ROBOSENSE_NEAR_ZERO)))
        {
            return true;
        }
        return false;
    }

    bool computeZ(const pcl::PointXYZI& pt1,const pcl::PointXYZI& pt2)
    {
        return pt1.z < pt2.z;
    }

    bool isNanPoint(const pcl::PointXYZI& pt)
    {
        if (std::isnan(pt.x) || std::isnan(pt.y) || std::isnan(pt.z))
        {
            return true;
        }
        return false;
    }

    void getTransformMat(const std::vector<float>& in_vec,Eigen::Matrix4f& out_tranform_mat)
    {
        out_tranform_mat = Eigen::Matrix4f::Identity();
        float tx = in_vec[1];
        float ty = in_vec[2];
        float tz = in_vec[3];
        float rx = in_vec[4];
        float ry = in_vec[5];
        float rz = in_vec[6];

        Eigen::AngleAxisf init_rotation_x(rx, Eigen::Vector3f::UnitX());
        Eigen::AngleAxisf init_rotation_y(ry, Eigen::Vector3f::UnitY());
        Eigen::AngleAxisf init_rotation_z(rz, Eigen::Vector3f::UnitZ());

        Eigen::Translation3f init_translation(tx, ty, tz);

        Eigen::Matrix4f init_guess =
                (init_translation * init_rotation_z * init_rotation_y * init_rotation_x).matrix();
        out_tranform_mat = init_guess;
    }

    Range3D::Range3D()
    {
        xmin = xmax = ymin = ymax = zmin = zmax = 0;
    }

    Range3D::Range3D(float x_min, float x_max, float y_min, float y_max, float z_min, float z_max)
    {
        xmin = x_min; xmax = x_max;
        ymin = y_min; ymax = y_max;
        zmin = z_min; zmax = z_max;
    }

    Range3D::Range3D(const Range3D &r)
    {
        xmin = r.xmin; xmax = r.xmax;
        ymin = r.ymin; ymax = r.ymax;
        zmin = r.zmin; zmax = r.zmax;
    }

    Range3D& Range3D::operator=(const Range3D &r)
    {
        if(this == &r)
            return *this;

        this->xmin = r.xmin; this->xmax = r.xmax;
        this->ymin = r.ymin; this->ymax = r.ymax;
        this->zmin = r.zmin; this->zmax = r.zmax;

        return *this;
    }
}
