//
// Created by mjj on 17-11-13.
//

#include "dependence/cart_grid.h"

namespace Robosense{
    CartGrid::CartGrid(){
        setGrid();
        leave_cloud_ptr_.reset(new pcl::PointCloud<pcl::PointXYZI>);
    }

    void CartGrid::setUserDefineCartHT(float (*pf)(const pcl::PointXYZI& )){
        computeCartHeightThre_ = pf;
        setConditionMat();
    }

    float CartGrid::computeCartHeightThre(const pcl::PointXYZI& in_pt){
        return 0.;
    }

    void CartGrid::setConditionMat(){
        height_thre_mat_ = cv::Mat::zeros(grid_length_,grid_width_,CV_32F);
        for (int j = 0; j < grid_length_; ++j) {
            for (int i = 0; i < grid_width_; ++i) {
                pcl::PointXYZI tmp_pt;
                tmp_pt.x = range_.xmin + (i * grid_size_ + grid_size_ / 2.);
                tmp_pt.y = range_.ymin + (j * grid_size_ + grid_size_ / 2.);
                if (computeCartHeightThre_ == NULL){
                    height_thre_mat_.at<float>(j,i) = std::max(computeCartHeightThre(tmp_pt), range_.zmax);
                }else{
                    height_thre_mat_.at<float>(j,i) = std::max(computeCartHeightThre_(tmp_pt), range_.zmax);
                }
            }
        }
    }

    bool CartGrid::cartGrid(const pcl::PointCloud<pcl::PointXYZI>::ConstPtr in_cloud_ptr,
                            std::vector<std::vector<std::vector<pcl::PointXYZI> > >& grids){
        if (in_cloud_ptr->empty()){
            std::cout<<"input cloud for cart grid is empty!!"<<std::endl;
            return false;
        }

        grids.clear();
        grids.resize(grid_length_);
        for (int j = 0; j < grid_length_; ++j) {
            grids[j].resize(grid_width_);
        }
        leave_cloud_ptr_->clear();

        for (int k = 0; k < in_cloud_ptr->size(); ++k) {
            pcl::PointXYZI tmp_pt = in_cloud_ptr->points[k];
            if (isNanPoint(tmp_pt))continue;
            if (tmp_pt.x < range_.xmin || tmp_pt.x > range_.xmax || tmp_pt.y < range_.ymin || tmp_pt.y > range_.ymax){
                leave_cloud_ptr_->push_back(tmp_pt);
                continue;
            }

            int x_index = (tmp_pt.x - range_.xmin) / grid_size_;
            int y_index = (tmp_pt.y - range_.ymin) / grid_size_;
            if (tmp_pt.z > height_thre_mat_.at<float>(y_index,x_index)|| tmp_pt.z < range_.zmin){
                leave_cloud_ptr_->push_back(tmp_pt);
                continue;
            }
            grids[y_index][x_index].push_back(tmp_pt);
        }

        for (int j = 0; j < grid_length_; ++j) {
            for (int i = 0; i < grid_width_; ++i) {
                std::sort(grids[j][i].begin(),grids[j][i].end(),computeZ);
            }
        }

        return true;
    }

    void CartGrid::getGridPtsSize(cv::Point2i& size){
        size.x = grid_width_;
        size.y = grid_length_;
    }

    bool CartGrid::getIndex(const pcl::PointXYZI& in_pt,cv::Point2i& out_index){
        if (isNanPoint(in_pt)){
            std::cerr<<"illegal in point for get cart grid index!"<<std::endl;
            return false;
        }
        if (in_pt.x < range_.xmin || in_pt.x > range_.xmax
            || in_pt.y < range_.ymin || in_pt.y > range_.ymax){
            std::cout<<"in point is out of range to get cart grid index!"<<std::endl;
            return false;
        }
        out_index.x = (in_pt.x - range_.xmin) / grid_size_;
        out_index.y = (in_pt.y - range_.ymin) / grid_size_;
        return true;
    }

    void CartGrid::getLeavePts(pcl::PointCloud<pcl::PointXYZI>::Ptr leave_cloud_ptr){
        *leave_cloud_ptr = *leave_cloud_ptr_;
    }

    bool CartGrid::setGrid(const Range3D& range,const float& size){
        if (range.xmin >= range.xmax || range.ymin >= range.ymax || range.zmin >= range.zmax){
            std::cerr<<"illegal params for set grid range!!"<<std::endl;
            return false;
        }
        if (size <= 0){
            std::cerr<<"illegal params for set grid size!!"<<std::endl;
            return false;
        }
        grid_size_ = size;
        range_ = range;
        grid_width_ = (range_.xmax - range_.xmin) / grid_size_ + 1;
        grid_length_ = (range_.ymax - range_.ymin) / grid_size_ + 1;
        setConditionMat();
        return true;
    }
}